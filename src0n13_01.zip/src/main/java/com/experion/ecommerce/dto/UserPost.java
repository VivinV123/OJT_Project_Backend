package com.experion.ecommerce.dto;

import lombok.Data;

@Data
public class UserPost {
//    private String userId;
//    private String userName;
//    private String userEmail;
    private String userToken;
}
