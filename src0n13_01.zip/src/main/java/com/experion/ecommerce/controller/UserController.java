package com.experion.ecommerce.controller;

import com.experion.ecommerce.dto.UserPost;
import com.experion.ecommerce.service.UserService;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/user")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

//    @PostMapping("/add")
//    public UserPost addUser(@RequestBody UserPost request) {
//        System.out.println("dataaaa"+request);
//        return userService.addUser(request);
//    }
    @PostMapping("/token")
    public JSONObject getToken(@RequestBody UserPost request) throws ParseException {
        logger.info("Token received ");
        System.out.println("heeko");
        return userService.getToken(request);
    }
}
