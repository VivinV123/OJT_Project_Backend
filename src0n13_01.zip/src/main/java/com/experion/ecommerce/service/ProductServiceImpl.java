package com.experion.ecommerce.service;

import com.experion.ecommerce.dao.ProductDao;
import com.experion.ecommerce.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class ProductServiceImpl implements ProductService {


    @Autowired
    private ProductDao productDao;

 public List<Product> findAllProduct(String category){
     if(category == null)
         return productDao.findAll();
     else {
         return productDao.findAlByproductCategory(category);
     }

 }


 public List<Product> findProductWithSorting(String field){
     return productDao.findAll(Sort.by(Sort.Direction.ASC, field));

 }
    public List<Product> findProductWithSortingDescend(String field){
        return productDao.findAll(Sort.by(Sort.Direction.DESC, field));

    }

}
