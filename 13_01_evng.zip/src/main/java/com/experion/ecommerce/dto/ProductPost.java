package com.experion.ecommerce.dto;public class ProductPost {
}
