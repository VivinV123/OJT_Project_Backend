package com.experion.ecommerce.service;

import com.experion.ecommerce.entity.Product;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
@Service
public interface ProductService {


    List<Product> findAllProduct(String category, String sortBy);



    List<Product> findProductWithSorting(String field);

    List<Product> findProductWithSortingDescend(String field);
}
