package com.experion.ecommerce.service;

import com.experion.ecommerce.dao.UserDao;
import com.experion.ecommerce.dto.UserPost;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public interface UserService {

//    @Autowired
//    private UserDao userDao;

//    UserPost addUser(UserPost request);

    JSONObject getToken(UserPost request) throws ParseException;

//    UserPost addUser(UserPost request);


}
