package com.experion.ecommerce.service;

import com.experion.ecommerce.dao.UserDao;
import com.experion.ecommerce.dto.UserPost;
import com.experion.ecommerce.entity.User;
import lombok.AllArgsConstructor;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserDao userDao;

    @Override
public JSONObject getToken(UserPost token) throws ParseException {

//User user = new User();
//System.out.println("hii"+request);
        String[] chunks = token.getUserToken().split("\\.");
        Base64.Decoder decoder = Base64.getUrlDecoder();

        String payloads = new String(decoder.decode(chunks[1]));
        System.out.println("typesss "+payloads.getClass().getName());
        JSONParser parser = new JSONParser(JSONParser.MODE_JSON_SIMPLE);
        JSONObject jsonResponse = (JSONObject) parser.parse(payloads);
        System.out.println("json "+jsonResponse);
        System.out.println("typesss "+jsonResponse.getClass().getName());
        System.out.println("email "+jsonResponse.getAsString("email"));
        System.out.println("name "+jsonResponse.getAsString("name"));
        System.out.println("picture "+jsonResponse.getAsString("picture"));
        User user = new User();
        user.setUserId(user.getUserId());
        user.setUserName(jsonResponse.getAsString("name"));
        user.setUserEmail(jsonResponse.getAsString("email"));
        user.setUserPicture(jsonResponse.getAsString("picture"));
        userDao.save(user);

        return jsonResponse;
    }

//    @Override
//    public UserPost addUser(UserPost request){
//        User user = new User();
//        user.setUserId(user.getUserId());
//
//return request;
//    }
}
