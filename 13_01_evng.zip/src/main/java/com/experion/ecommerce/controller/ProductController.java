package com.experion.ecommerce.controller;

import com.experion.ecommerce.entity.Product;
import com.experion.ecommerce.service.ProductService;
import com.experion.ecommerce.service.ProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/all")
    public List<Product> getProduct(
            @RequestParam(value = "productCategory", required = false) String category,
            @RequestParam(value = "sortBy",required = false) String sortBy)

          {
      return productService.findAllProduct(category,sortBy);
    }




    @GetMapping("/{field}/asc")
    public List<Product> getProductwithSort(@PathVariable String field){
        List<Product> allProduct = productService.findProductWithSorting(field);
        return allProduct;

    }

    @GetMapping("/{field}/desc")
    public List<Product> findProductWithSortingDescend(@PathVariable String field){
        List<Product> allProduct = productService.findProductWithSortingDescend(field);
        return allProduct;

    }
}
